<?php	
include('conn.php');
if(isset($_GET['id'])){
	$id = $_GET['id'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<style>
		@import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;1,100;1,300;1,400;1,500;1,600&display=swap');

		* {
			font-family: 'Poppins', sans-serif !important;
			margin: 0%;
			padding: 0%;
			box-sizing: border-box;
		}

		.H3School {
			background-color: white;
			color: aliceblue;
			font-size: 15px;
		}

		nav {
			width: 100%;
			height: 50px;
			/* position: fixed;	 */
			line-height: 50px;
			background-color: #5A6F92;
		}

		ul {
			float: left;
		}

		li {
			display: inline;
		}

		li a {
			color: aliceblue;
			/* text-transform: uppercase; */
			padding: 0px 20px;
			text-decoration: none;
		}

		li a:hover {
			background-color: darkgreen;
		}

		.Section {
			display: flex;
		}

		#hero-1 {
			background-color: white;
			color: black;
			/* height: 100vh; */
			width: 70%;
			display: flex;
			align-items: center;
			flex-direction: column;
		}

		#r {
			width: 90%;
			height: auto;
			background-color: white;
			padding: 20px;
			margin-top: 20px;
			display: flex;
			border-radius: 15px;
			align-items: center;
			flex-direction: column;
			box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.397);
		}

		#r1 h1 {
			color: #2F4469;
			font-weight: 600 !important;
		}

		#r2 {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin: 10px 10px;
			width: 100%;
		}

		#r4 {
			display: flex;
			justify-content: center;
			align-items: center;
			flex-direction: column;
			width: 55%;
			/* margin-top: 30px; */
		}

		/* #hero-2 {
			background-color: red;
			width: 30%;
			height: 400px;
		} */

		#nav {
			display: flex;
			justify-content: center;
			align-items: center;
			display: inline-block;
			background-color: orange;
			height: 70px;
			width: 100%;
		}

		ul {
			display: inline-block;
		}

		#head {
			height: 70px;
			width: 100%;
			background-color: #2F4468;
			display: flex;
			justify-content: center;
			align-items: center;
			justify-content: space-around;
		}

		form {
			width: 100%;
		}

		#head ul {
			float: right;
		}

		#head ul li {
			line-height: 60px;
			padding: 0px 20px;
		}

		#head1 {
			color: white;
			padding-left: 20px;
			font-size: 25px;
		}

		#head2 {
			font-size: 20px;
		}

		input[type=submit] {
			height: 50px;
			width: 100px;
			border-radius: 10px;
			border: 1px solid white;
			cursor: pointer;
			margin-top: 40px;
		}
	</style>
</head>

<body>
	<nav>
		<div class="H3School">
			<ul>
				<li><a href="http://localhost/blog/#">Home</a></li>
				<li><a href="#">About</a></li>
				<li><a href="#">Contact Us</a></li>
				<li><a href="#">Disclaimer</a></li>
				<li><a href="#">Privacy policy</a></li>
				<li><a href="#">Terms and Conditions</a></li>
			</ul>
		</div>
	</nav>
	<div id="head">
		<div id="head1">
			Health Sphere
		</div>
		<div id="head2">
			<ul>
				<li>
					<a href="http://localhost/blog/#">Home</a>
					<a href="#">Health care</a>
					<a href="#">Dental care</a>
					<a href="#">Fitness</a>
					<a href="#">Beauty</a>
					<a href="#">Disease</a>
				</li>
			</ul>
		</div>

	</div>
	<?php
		$sql = "SELECT * FROM `content` where id= $id";
		$query = mysqli_query($conn, $sql);
		$row = mysqli_fetch_assoc($query);
	?>
	<div class="Hero">
		<br>
		<h2>
			<?php echo $row['Title'];?>
		</h2><br>
		<?php echo $row['Description'];?>
	</div>
</body>

</html>