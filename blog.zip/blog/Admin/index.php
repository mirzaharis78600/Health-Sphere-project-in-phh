<?php
	include('../conn.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<style>
		@import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;1,100;1,300;1,400;1,500;1,600&display=swap');

		* {
			font-family: 'Poppins', sans-serif !important;
			margin: 0%;
			padding: 0%;
		}

		body {
			background-color: #F0F0F1;

		}

		.myself {
			display: flex;
			justify-content: center;
			align-items: center;
			flex-direction: column;
		}

		.section {
			background-color: white;
			width: 300px;
			margin-top: 20px;
			/* display: flex;
			justify-content: center;
			align-items: center; 
			margin: 0px 300px;      */
			padding: 25px 15px;
			border: 1px solid #ccc;
		}

		.hero {
			margin-bottom: 20px;
		}

		label {
			display: inline-block;
		}

		input[type=text],
		input[type=password] {
			width: 100%;
			padding: 10px 0px;
			border-radius: 5px;
			border: 1px solid hsl(0, 0%, 80%);
		}

		input[type=submit] {
			float: right;
			padding: 7px 10px;
			background-color: blueviolet;
			color: white;
			border-radius: 4px;
			cursor: pointer;
			border: 1px solid #ccc;
		}

		.hero-1 {
			width: 200px;
			/* margin: 70px 200px; */
			display: flex;
			justify-content: center;
			align-items: center;
			margin-top: 60px;
		}

		p {
			color: black;
			font-family: 'Courier New', Courier, monospace;
		}

		#heroo {
			margin-top: 25px;
			text-decoration: none;
			/* float: left;
			padding: 10px 0px; */
			/* float: center !important; */
			margin-left: 38%;
			/* text-decoration-color: black; */
		}
	</style>
</head>

<body>

	<div class="myself">
		<div class="hero-1">
			<img src="wordpress.jpg" height="100px" width="125px">
		</div>
		<div class="section">
			<form action="Login.php" method="post">
				<div class="hero">
					<label for="">Username or Email Address</label>
					<input type="text" name="username" required>
		
				</div>
				<div class="hero">
					<label for="">Password</label>
					<input type="password" name="password" required>
				</div>
				<div class="hero">
					<input type="checkbox"> Remember Me
					<input type="submit" name="Login" value="Log In">
				</div>
			</form>
		</div>
	</div>

	<div id="heroo">
		<a href="http://localhost/blog/">Go to HealthSphere</a>
	</div>
</body>

</html>