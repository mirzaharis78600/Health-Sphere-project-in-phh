<?php
		include('../conn.php');
	if(isset($_POST['Login'])){
		// echo "Hello";
	$username = $_POST["username"];
	$password = $_POST["password"];
		
		$sql = "SELECT * FROM `admin` WHERE $username = 'username' AND $password = 'password' ";
		$query = mysqli_query($conn, $sql);
		$count = mysqli_num_rows($query);
		if($count==1){
			// echo "data inserted successfully";
			echo '<script>
			window.location.href="Details.php";
			 alert(" Successfully Login");</script>';
		}
		else{
			// echo "error while inserted data";
			echo '<script>
			window.location.href = "index.php";
				alert("Wrong Details");</script>';
		}
	}
	else{
		echo "while not found";
	}
	
?>
