
<?php
		include('../conn.php');
	if(isset($_POST['submit'])){
		// echo "Hello";
	$Title = $_POST["Title"];
	$file = $_FILES['uploadfile']['name'];
	$tmpfile = $_FILES['uploadfile']['tmp_name'];
	$folder = "uploads/";
	$Description = $_POST["Description"];
	$Slug = $_POST["Slug"];

		
		$sql = "insert into content value('', '$Title', '$Description' , '$Slug','$file') ";
		$query = mysqli_query($conn, $sql);
		move_uploaded_file($tmpfile,$folder.$file);
		// $count = mysqli_num_rows($query);
		if($query){
			header('location: Details.php');
			
			// echo '<script>
			// window.location.href="Details.php";
			//  alert(" Successfully Login");</script>';
		}
		else{
			
			echo "error while inserted data";
			// echo '<script>
			// window.location.href = "index.php";
			// 	alert("Wrong Details");</script>';
		}
	}
	else{
		echo "while not found dhgfhdgfhdg";
	}
	
?>