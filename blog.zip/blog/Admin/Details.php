<?php
include('../conn.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<style>
		body {
			background-color: wheat;
		}

		form {
			background-color: white;
			/* width: 600px; */
			width: auto;
			margin: 70px auto;
			padding: 20px;
		}

		.hero {
			margin-bottom: 20px;
		}

		label {
			display: inline-block;
			/* font-weight: 400; */
			font-weight: bold;
		}

		input[type=text] {
			width: 95%;
			padding: 10px;
			border-radius: 5px;
			border: 1px solid #ccc;
		}

		input[type=submit] {
			background-color: blueviolet;
			color: white;
			padding: 10px 15px;
			cursor: pointer;
			border-radius: 5px;
			border: 1px solid #ccc;
		}

		textarea {
			width: 95%;
			padding: 50px 0px;
		}
	</style>
</head>

<body>
	<div class="Section">
		<form action="Addblog.php" method="post" enctype="multipart/form-data">
			<h2>HealthSphere Form</h2>
			<div class="hero">
				<label for="">Title</label>
				<input type="text" name="Title" placeholder="Enter your favourite Title" required>
			</div>
			<div class="hero">
				<label for="">Description</label><br>
				<!-- <label for="">Description</label> -->
				<textarea name="Description" id="Description" rows="4" cols="50"></textarea>
			</div>
			<div class="hero">
				<label for="">Slug</label>
				<input type="text" name="Slug" placeholder="Enter your Slug" required>
			</div>
			<!-- <input type="file" name="file" id="file"><br> -->
	
				<label for=""><b>SELECT IMAGE TO UPLOADS</b></label><br>
				<br><input type="file" name="uploadfile"><br>
				<input type="submit" name="submit" value="submit" class="btn">				
		</form>
	</div>
</body>

</html>