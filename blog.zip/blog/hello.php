<html>
    <title>Demo</title>
</html>
<body>
    <?php
    echo "Hello World";
    ?>
</body>