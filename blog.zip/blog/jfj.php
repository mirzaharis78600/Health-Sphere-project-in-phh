<?php
include('conn.php');
$sql = mysqli_query($conn, "SELECT * FROM `content`");
while ($row = mysqli_fetch_assoc($sql)) {
    // $imag = $row['image'];
// Assuming $row['image_data'] contains the binary image data
header("Content-type: image/jpeg"); // Adjust the content type based on your image format
echo $row['image_data'];
    echo "$imag";
    echo "<img src='uploads/{$row['image']}' alt=''>";
}
?>